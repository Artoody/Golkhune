#include <WiFi.h>
#include <DHT.h>

// =========================
// Wi-Fi
// =========================
const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// =========================
// Sensor Pins
// =========================
#define DHT_PIN 15
#define DHT_TYPE DHT22

#define SOIL_MOISTURE_PIN 34
#define LDR_PIN 35

// =========================
// DHT Sensor
// =========================
DHT dht(DHT_PIN, DHT_TYPE);

// =========================
// Wi-Fi Connection
// =========================
void connectWiFi() {
  Serial.println();
  Serial.println("Connecting to Wi-Fi...");

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;

  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Wi-Fi connected!");

    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());

    Serial.print("RSSI: ");
    Serial.print(WiFi.RSSI());
    Serial.println(" dBm");
  } else {
    Serial.println("Wi-Fi connection failed.");
  }
}

// =========================
// Setup
// =========================
void setup() {

  Serial.begin(115200);
  delay(1000);

  Serial.println("==============================");
  Serial.println("   Golkhune ESP32 Starting");
  Serial.println("==============================");

  // Start DHT
  dht.begin();

  // Connect Wi-Fi
  connectWiFi();
}

// =========================
// Loop
// =========================
void loop() {

  // -------------------------
  // Wi-Fi reconnect
  // -------------------------
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi disconnected!");
    Serial.println("Trying to reconnect...");

    connectWiFi();
  }

  // -------------------------
  // Read DHT22
  // -------------------------
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  // -------------------------
  // Read Soil Moisture
  // -------------------------
  int soilRaw = analogRead(SOIL_MOISTURE_PIN);

  // Convert to percentage
  int soilMoisture = map(soilRaw, 4095, 0, 0, 100);

  soilMoisture = constrain(soilMoisture, 0, 100);

  // -------------------------
  // Read LDR
  // -------------------------
  int lightRaw = analogRead(LDR_PIN);

  // Convert to percentage
  int lightLevel = map(lightRaw, 0, 4095, 0, 100);

  lightLevel = constrain(lightLevel, 0, 100);

  // -------------------------
  // Display results
  // -------------------------
  Serial.println();
  Serial.println("------------------------------");
  Serial.println("       SENSOR DATA");
  Serial.println("------------------------------");

  if (isnan(temperature) || isnan(humidity)) {

    Serial.println("DHT22: ERROR");

  } else {

    Serial.print("Temperature: ");
    Serial.print(temperature);
    Serial.println(" °C");

    Serial.print("Humidity: ");
    Serial.print(humidity);
    Serial.println(" %");
  }

  Serial.print("Soil Moisture: ");
  Serial.print(soilMoisture);
  Serial.println(" %");

  Serial.print("Light Level: ");
  Serial.print(lightLevel);
  Serial.println(" %");

  // -------------------------
  // System information
  // -------------------------
  Serial.print("Wi-Fi: ");

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("CONNECTED");
  } else {
    Serial.println("DISCONNECTED");
  }

  Serial.print("Uptime: ");
  Serial.print(millis() / 1000);
  Serial.println(" seconds");

  delay(3000);
}