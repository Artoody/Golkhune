#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

WebServer server(80);

void trigger() {
  digitalWrite(2, HIGH);

  server.send(200, "text/plain", "ESP32 TRIGGERED!");

  delay(1000);

  digitalWrite(2, LOW);
}

void setup() {

  Serial.begin(115200);

  pinMode(2, OUTPUT);

  // وصل شدن ESP32 به WiFi
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi connected!");

  Serial.print("ESP32 IP: ");
  Serial.println(WiFi.localIP());

  // وقتی /trigger آمد، تابع trigger اجرا شود
  server.on("/trigger", HTTP_GET, trigger);

  // شروع Web Server
  server.begin();

  Serial.println("Server started!");
}

void loop() {

  // منتظر Request بمان
  server.handleClient();
}